import { Route } from 'react-router-dom';
import  {Navigate}  from 'react-router-dom';

const ProtectedRoute = ({ allowedRoles, userRole, ...rest }) => {
  if (allowedRoles.includes(userRole)) {
    return <Route {...rest} />;
  } else {
    // return <Redirect to="/unauthorized" />;
    return Navigate("/unauthorized");
  }
};

export default ProtectedRoute;