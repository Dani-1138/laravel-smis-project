import "bootstrap/dist/css/bootstrap.min.css";
import { useState } from 'react';
import { Button, Modal, Input } from 'react-bootstrap';
//cp
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchStudentsRequest } from '../redux/actions/studentActions';
import { Link } from "react-router-dom";
import { Navigate } from "react-router-dom";
import { updateStudentRequest } from "../redux/actions/studentActions";

function ViewStudentTable() {

  const [id, setId] = useState('');
  const [firstName, setFirstName] = useState('');
  const [middleName, setMiddleName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [sex, setSex] = useState('');
  const [age, setAge] = useState(0);
  const [phone, setPhone] = useState(0);
  const [entranceResult, setEntranceResult] = useState(0);
  const [cgpa, setCgpa] = useState(0);
  const [cocResult, setCocResult] = useState(0);
  const [department, setDepartment] = useState('');
  const [batch, setBatch] = useState(0);
  const [status, setStatus] = useState('');




  const dispatch = useDispatch();
  const students = useSelector(state => state.students.students);
  const loading = useSelector(state => state.students.loading);
  const [show, setShow] = useState(false);

  const data = {
    student_id:id,
    firstName:firstName,
    middleName:middleName,
    lastName:lastName,
    email:email,
    password:password,
    sex:sex,
    age:age,
    phone:phone,
    entranceResult:entranceResult,
    cgpa:cgpa,
    cocResult:cocResult,
    department:department,
    batch:batch,
    status:status
}

  const updateStudent = (e) => {
    e.preventDefault();
    dispatch(updateStudentRequest(id,data));
    console.log(data);
  };

  const updateId=(id)=>{
        
  }

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  useEffect(() => {
    // Dispatch the fetchStudentsRequest action when the component mounts
    dispatch(fetchStudentsRequest());
    console.log(students);
  }, []);

  if (loading) {
    return <div>Loading...</div>;
  }

  return (

    <div class="container ">
      <div className="crud shadow-lg p-3 mb-5 mt-5 bg-body rounded">
        <div class="row ">

          <div class="col-sm-3 mt-5 mb-4 text-gred">
            <div className="search">
              <form class="form-inline">
                <input class="form-control mr-sm-2" type="search" placeholder="Search Student" aria-label="Search" />

              </form>
            </div>
          </div>
          <div class="col-sm-3 offset-sm-2 mt-5 mb-4 text-gred" style={{ color: "green" }}><h2><b>Student Details</b></h2></div>
          <div class="col-sm-3 offset-sm-1  mt-5 mb-4 text-gred">

            <Button variant="primary" onClick={handleShow}>
              Add New Student
            </Button>
          </div>
        </div>
        <div class="row">
          <div class="table-responsive " >
            <table class="table table-striped table-hover table-bordered">
              <thead>
                <tr>
                  <th>Id</th>
                  <th>First Name </th>
                  <th>Middle Name</th>
                  <th>Last Name </th>
                  <th>Age</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {students.map(student =>
                  <tr>
                    <td>{student.student_id}</td>
                    <td>{student.firstName}</td>
                    <td>{student.middleName}</td>
                    <td>{student.lastName}</td>
                    <td>{student.age}</td>

                    <td>
                      <a href="#" class="view" title="View" data-toggle="tooltip" style={{ color: "#10ab80" }}><i class="material-icons">&#xE417;</i></a>
                      <a href="#" onClick={handleShow} class="edit" title="Edit" data-toggle="tooltip"><i class="material-icons" onClick={updateStudent}>&#xE254;</i></a>
                      <a href="#" class="delete" title="Delete" data-toggle="tooltip" style={{ color: "red" }}><i class="material-icons">&#xE872;</i></a>
                    </td>
                  </tr>)}

                {/* <tr>
                            <td>2</td>
                            <td>Demark</td>
                            <td>City Road.13</td>
                            <td>Dubai</td>
                            <td>UAE</td>
                            <td>
                            <a href="#" class="view" title="View" data-toggle="tooltip" style={{color:"#10ab80"}}><i class="material-icons">&#xE417;</i></a>
                                <a href="#" class="edit" title="Edit" data-toggle="tooltip"><i class="material-icons">&#xE254;</i></a>
                                <a href="#" class="delete" title="Delete" data-toggle="tooltip" style={{color:"red"}}><i class="material-icons">&#xE872;</i></a>
                            </td>
                        </tr>
                         
 
                        <tr>
                            <td>3</td>
                            <td>Richa Deba</td>
                            <td>Ocol Str. 57</td>
                            <td>Berlin</td>
                            <td>Germany</td>
                            <td>
                            <a href="#" class="view" title="View" data-toggle="tooltip" style={{color:"#10ab80"}}><i class="material-icons">&#xE417;</i></a>
                                <a href="#" class="edit" title="Edit" data-toggle="tooltip"><i class="material-icons">&#xE254;</i></a>
                                <a href="#" class="delete" title="Delete" data-toggle="tooltip" style={{color:"red"}}><i class="material-icons">&#xE872;</i></a>
                            </td>
                        </tr>
 
                        <tr>
                            <td>4</td>
                            <td>James Cott</td>
                            <td>Berut Road</td>
                            <td>Paris</td>
                            <td>France</td>
                            <td>
                            <a href="#" class="view" title="View" data-toggle="tooltip" style={{color:"#10ab80"}}><i class="material-icons">&#xE417;</i></a>
                                <a href="#" class="edit" title="Edit" data-toggle="tooltip"><i class="material-icons">&#xE254;</i></a>
                                <a href="#" class="delete" title="Delete" data-toggle="tooltip" style={{color:"red"}}><i class="material-icons">&#xE872;</i></a>
                            </td>
                        </tr>
 
 
                        <tr>
                            <td>5</td>
                            <td>Dheraj</td>
                            <td>Bulf Str. 57</td>
                            <td>Delhi</td>
                            <td>India</td>
                            <td>
                            <a href="#" class="view" title="View" data-toggle="tooltip" style={{color:"#10ab80"}}><i class="material-icons">&#xE417;</i></a>
                                <a href="#" class="edit" title="Edit" data-toggle="tooltip"><i class="material-icons">&#xE254;</i></a>
                                <a href="#" class="delete" title="Delete" data-toggle="tooltip" style={{color:"red"}}><i class="material-icons">&#xE872;</i></a>
                            </td>
                        </tr>
 
 
                        <tr>
                            <td>6</td>
                            <td>Maria James</td>
                            <td>Obere Str. 57</td>
                            <td>Tokyo</td>
                            <td>Japan</td>
                            <td>
                            <a href="#" class="view" title="View" data-toggle="tooltip" style={{color:"#10ab80"}}><i class="material-icons">&#xE417;</i></a>
                                <a href="#" class="edit" title="Edit" data-toggle="tooltip"><i class="material-icons">&#xE254;</i></a>
                                <a href="#" class="delete" title="Delete" data-toggle="tooltip" style={{color:"red"}}><i class="material-icons">&#xE872;</i></a>
                            </td>
                        </tr> */}
              </tbody>
            </table>
          </div>
        </div>

        {/* <!--- Model Box ---> */}
        <div className="model_box">
          <Modal
            show={show}
            onHide={handleClose}
            backdrop="static"
            keyboard={false}
          >
            <Modal.Header closeButton>
              <Modal.Title>Add Record</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <form onSubmit={updateStudent}>
                <div className="mb-3">
                  <label>Id</label>
                  <input type="text" name="id" className="form-control"
                    value={students.student_id}
                    onChange={(e) => setId(e.target.value)} />
                </div>
                <div className="mb-3">
                  <label>First Name</label>
                  <input type="text"
                    name="fname"
                    className="form-control"
                    onChange={(e) => setFirstName(e.target.value)} />
                </div>
                <div className="mb-3">
                  <label>Middle Name</label>
                  <input type="text" name="mname" className="form-control"

                    onChange={(e) => setMiddleName(e.target.value)} />
                </div>
                <div className="mb-3">
                  <label>Last Name</label>
                  <input type="text" name="lname" className="form-control"

                    onChange={(e) => setLastName(e.target.value)} />
                </div>
                <div className="mb-3">
                  <label>Email</label>
                  <input type="email" name="email" className="form-control"

                    onChange={(e) => setEmail(e.target.value)} />
                </div>
                <div className="mb-3">
                  <label>Password</label>
                  <input type="text" name="password" className="form-control"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)} />
                </div>
                <div className="mb-3">
                  <label>Age</label>
                  <input type="text" name="age" className="form-control"

                    onChange={(e) => setAge(e.target.value)} />
                </div>
                <div className="mb-3">
                  <label>Sex</label>
                  <input type="text" name="sex" className="form-control"

                    onChange={(e) => setSex(e.target.value)} />
                </div>
                <div className="mb-3">
                  <label>Phone Number</label>
                  <input type="text" name="phone" className="form-control"

                    onChange={(e) => setPhone(e.target.value)} />
                </div>
                <div className="mb-3">
                  <label>Batch</label>
                  <input type="text" name="batch" className="form-control"

                    onChange={(e) => setBatch(e.target.value)} />
                </div>
                <div className="mb-3">
                  <label>Department</label>
                  <input type="text" name="dept" className="form-control"

                    onChange={(e) => setDepartment(e.target.value)} />
                </div>
                <div className="mb-3">
                  <label>COC Result</label>
                  <input type="text" name="coc" className="form-control"

                    onChange={(e) => setCocResult(e.target.value)} />
                </div>
                <div className="mb-3">
                  <label>Entrace Result</label>
                  <input type="text" name="entrance" className="form-control"
                    onChange={(e) => setEntranceResult(e.target.value)} />
                </div>
                <div className="mb-3">
                  <label>CGPA</label>
                  <input type="text" name="gpa" className="form-control"
                    onChange={(e) => setCgpa(e.target.value)} />
                </div>
                <div className="mb-3">
                  <label>Status</label>
                  <input type="text" name="status" className="form-control"

                    onChange={(e) => setStatus(e.target.value)} />
                </div>

                <button type="submit" class="btn btn-success mt-4">Add Record</button>
              </form>
            </Modal.Body>

            <Modal.Footer>
              <Button variant="secondary" onClick={handleClose}>
                Close
              </Button>

            </Modal.Footer>
          </Modal>

          {/* Model Box Finsihs */}
        </div>
      </div>
    </div>
  );
}

export default ViewStudentTable;