import "bootstrap/dist/css/bootstrap.min.css";
import {useState} from 'react';
import { Button,Modal,Input } from 'react-bootstrap';
import "./global.css"
//cp
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchDepartmentsRequest } from '../redux/actions/departmentActions';
import { addDepartmentRequest } from "../redux/actions/departmentActions";
 
function ViewDepartmentTable() {

    const dispatch = useDispatch();
    const [department, setDepartment] = useState('');
    const [intake, setIntake] = useState(0);
    const [status, setStatus] = useState('');
    const departments = useSelector(state => state.departments.departments);
    const loading = useSelector(state => state.departments.loading);
    const [show, setShow] = useState(false);
      const error = useSelector(state => state.departments.error);
    
      const data = {
        department:department,
        intake:intake,
        status:status,

    }

      const handleSubmit = (e) => {
        e.preventDefault();
        dispatch(addDepartmentRequest(data));
        console.log(data);
      };




 
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
  
    useEffect(() => {
      // Dispatch the fetchStudentsRequest action when the component mounts
      dispatch(fetchDepartmentsRequest());
      console.log(departments);
    }, [departments]);
  
    if (loading) {
      return <div>Loading...</div>;
    }
 
  return (
 
       <div class="container ">
          <div className="crud shadow-lg p-3 mb-5 mt-5 bg-body rounded"> 
          <div class="row ">
           
           <div class="col-sm-3 mt-5 mb-4 text-gred">
              <div className="search">
                <form class="form-inline">
                 <input class="form-control mr-sm-2" type="search" placeholder="Search department" aria-label="Search"/>
                
                </form>
              </div>    
              </div>  
              <div class="col-sm-3 offset-sm-2 mt-5 mb-4 text-gred" style={{color:"rgb(157, 199, 201)"}}><h2><b>Departments</b></h2></div>
              <div class="col-sm-3 offset-sm-1  mt-5 mb-4 text-gred">
              <Button variant="primary" onClick={handleShow}>
                Add Department
              </Button>
             </div>
           </div>  
            <div class="row">
                <div class="table-responsive " >
                 <table class="table table-striped table-hover table-bordered">
                    <thead >
                        <tr>
                            <th style={{backgroundColor:"rgb(157, 199, 201)"}}>#</th>
                            <th style={{backgroundColor:"rgb(157, 199, 201)"}}>Department </th>
                            <th style={{backgroundColor:"rgb(157, 199, 201)"}}>Intake Capacity</th>
                            <th style={{backgroundColor:"rgb(157, 199, 201)"}}>status</th>
                            <th style={{backgroundColor:"rgb(157, 199, 201)"}}>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                      
                {departments &&  departments.map((dep,index)=>(
                        <tr key={index}>
                            <td>{index}</td>
                            <td>{dep.department}</td>
                            <td>{dep.intake}</td>
                            <td>{dep.status}</td>
                            <td>
                               <a href="#" class="view" title="View" data-toggle="tooltip" style={{color:"#10ab80"}}><i class="material-icons">&#xE417;</i></a>
                                <a href="#" class="edit" title="Edit" data-toggle="tooltip"><i class="material-icons">&#xE254;</i></a>
                                <a href="#" class="delete" title="Delete" data-toggle="tooltip" style={{color:"red"}}><i class="material-icons">&#xE872;</i></a>
                                 
                            </td>
                        </tr>))
                        }
                        <tr>
                            <td>2</td>
                            <td>Information Technology</td>
                            <td>40</td>
                            <td>More</td>
                            <td>
                               <a href="#" class="view" title="View" data-toggle="tooltip" style={{color:"#10ab80"}}><i class="material-icons">&#xE417;</i></a>
                                <a href="#" class="edit" title="Edit" data-toggle="tooltip"><i class="material-icons">&#xE254;</i></a>
                                <a href="#" class="delete" title="Delete" data-toggle="tooltip" style={{color:"red"}}><i class="material-icons">&#xE872;</i></a>
                                 
                            </td>
                        </tr>
                         
 
                        <tr>
                            <td>3</td>
                            <td>Computer Science</td>
                            <td>40</td>
                            <td>More</td>
                            <td>
                               <a href="#" class="view" title="View" data-toggle="tooltip" style={{color:"#10ab80"}}><i class="material-icons">&#xE417;</i></a>
                                <a href="#" class="edit" title="Edit" data-toggle="tooltip"><i class="material-icons">&#xE254;</i></a>
                                <a href="#" class="delete" title="Delete" data-toggle="tooltip" style={{color:"red"}}><i class="material-icons">&#xE872;</i></a>
                                 
                            </td>
                        </tr>
 
                        <tr>
                            <td>4</td>
                            <td>Electrical and Computer Engineering</td>
                            <td>40</td>
                            <td>More</td>
                            <td>
                               <a href="#" class="view" title="View" data-toggle="tooltip" style={{color:"#10ab80"}}><i class="material-icons">&#xE417;</i></a>
                                <a href="#" class="edit" title="Edit" data-toggle="tooltip"><i class="material-icons">&#xE254;</i></a>
                                <a href="#" class="delete" title="Delete" data-toggle="tooltip" style={{color:"red"}}><i class="material-icons">&#xE872;</i></a>
                            </td>
                        </tr>
 
                    </tbody>
                </table>
            </div>   
        </div>  
 
        {/* <!--- Model Box ---> */}
        <div className="model_box">
      <Modal
        show={show}
        onHide={handleClose}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Header closeButton>
          <Modal.Title>Add Record</Modal.Title>
        </Modal.Header>
            <Modal.Body>
            <form onSubmit={handleSubmit}>
                <div class="form-group">
                    <input type="text" class="form-control" id="exampleInputEmail1" onChange={e => setDepartment(e.target.value)} aria-describedby="textHelp" placeholder="Enter Department"/>
                </div>
                <div class="form-group mt-3">
                    <input type="number" class="form-control" id="exampleInputEmail1" onChange={e => setIntake(e.target.value)} aria-describedby="emailHelp" placeholder="Enter Intake Capacity"/>
                </div>
                <div class="form-group mt-3">
                    <input type="text" class="form-control" id="exampleInputEmail1" onChange={e => setStatus(e.target.value)} aria-describedby="emailHelp" placeholder="Enter Student Satisfaction"/>
                </div>
                
                  <button type="submit" class="btn btn-success mt-4">Add Department</button>
                </form>
            </Modal.Body>
 
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          
        </Modal.Footer>
      </Modal>
  
       {/* Model Box Finsihs */}
       </div>  
      </div>    
      </div>  
  );
}
 
export default ViewDepartmentTable;