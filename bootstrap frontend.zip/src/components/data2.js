export const data = [
  {
    questionText: "Angular es definido como:",
    name: "q1-name",
    options: [
      { choice: "a) Framework", radioValue: "q1-a", selected: false },
      { choice: "b) librería", radioValue: "q1-b", selected: false },
      {
        choice: "c) Lenguage de programación",
        radioValue: "q1-c",
        selected: false,
      },
      {
        choice: "d) Ninguno de los anterirores",
        radioValue: "q1-d",
        selected: false,
      },
    ],
  },
  {
    questionText: "¿JavaScript es lo mismo que Java?",
    name: "q2-name",
    options: [
      { choice: "a) Si", radioValue: "q2-a", selected: false },
      { choice: "b) No", radioValue: "q2-b", selected: false },
      { choice: "c) Aveces", radioValue: "q2-c", selected: false },
      { choice: "d) Casi siempre", radioValue: "q2-d", selected: false },
    ],
  },
  {
    questionText:
      "Dado el siguiente arreglo: const arr = [10, 30, 44, 80]. ¿Cual de las siguientes opciones nos permite obtener el ultimo elemento del arreglo?",
    name: "q3-name",
    options: [
      { choice: "a) arr[1]", radioValue: "q3-a", selected: false },
      { choice: "b) arr[arr.length]", radioValue: "q3-b", selected: false },
      { choice: "c) arr[arr.length - 1]", radioValue: "q3-c", selected: false },
      { choice: "d) arr.length", radioValue: "q3-d", selected: false },
    ],
  },
  {
    questionText: "¿Es posible utilzar Redux en aplicaciones de Angular?",
    name: "q4-name",
    options: [
      { choice: "a) Si", radioValue: "q4-a", selected: false },
      { choice: "b) No", radioValue: "q4-b", selected: false },
    ],
  },
  {
    questionText: "¿Ionic esta basado en React?",
    name: "q5-name",
    options: [
      { choice: "a) Si", radioValue: "q5-a", selected: false },
      { choice: "b) No", radioValue: "q5-b", selected: false },
    ],
  },
];
