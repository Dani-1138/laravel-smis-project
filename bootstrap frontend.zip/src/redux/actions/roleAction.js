export const LOGIN_USER = 'LOGIN_USER';

export const loginUser = (userId, password) => ({
  type: LOGIN_USER,
  payload: { userId, password },
});