import { createStore, applyMiddleware, combineReducers } from 'redux';
import createSagaMiddleware from 'redux-saga';
import studentReducer from './reducers/studentReducer';
import departmentReducer from './reducers/departmentReducer';
import examReducer from './reducers/examReducer'
import rootSaga from './sagas/rootSaga';
import userReducer from './reducers/userReducer';
import roleReducer from './reducers/roleReducer';



const rootReducer = combineReducers({
  students: studentReducer,departments: departmentReducer,exams: examReducer, user: userReducer,role: roleReducer,
});

const sagaMiddleware = createSagaMiddleware();

const store = createStore(rootReducer, applyMiddleware(sagaMiddleware));

sagaMiddleware.run(rootSaga);

export default store;