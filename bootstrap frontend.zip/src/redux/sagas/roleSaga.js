import { call, put, takeLatest } from 'redux-saga/effects';
import axios from 'axios';
import { LOGIN_USER, loginUser } from '../actions/roleAction';

// Replace 'YOUR_BACKEND_API_URL' with the actual API endpoint for user login
const loginApi = (userId, password) => {
  return axios.post('http://localhost:8000/api/login', { userId, password });
};

function* handleLogin(action) {
  try {
    const { userId, password } = action.payload;
    const response = yield call(loginApi, userId, password);

    // Assuming the response data has the user's role, extract it and update the Redux state
    const role = response.data.role; // Replace 'role' with the actual property containing the role

    yield put(loginUser(role));
  } catch (error) {
    // Handle login error
    console.error('Login error:', error);
  }
}

function* userSaga() {
  yield takeLatest(LOGIN_USER, handleLogin);
}

export default userSaga;