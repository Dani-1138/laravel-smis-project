import { put, takeLatest, all } from 'redux-saga/effects';
import * as actionTypes from '../actions/studentActions';
import axios from 'axios';

// Replace 'YOUR_LARAVEL_API_ENDPOINT' with your actual Laravel API endpoint
const API_BASE_URL = 'http://localhost:8000/api';


// Add student
function* addStudentSaga(action) {
    try {
      const response = yield axios.post(`${API_BASE_URL}/addStudent`, action.payload);
      yield put(actionTypes.addStudentSuccess(response.data));
    } catch (error) {
      yield put(actionTypes.addStudentFailure(error.message));
    }
  }

// Fetch students
function* fetchStudentsSaga() {
  try {
    const response = yield axios.get(`${API_BASE_URL}/getstudent`);
    yield put(actionTypes.fetchStudentsSuccess(response.data));
    console.log(response.data);
  } catch (error) {
    yield put(actionTypes.fetchStudentsFailure(error.message));
  }
}

// Update student
function* updateStudentSaga(action) {
  try {
    const { studentId, data } = action.payload;
    const response = yield axios.put(`${API_BASE_URL}/students/${studentId}`, data);
    yield put(actionTypes.updateStudentSuccess(response.data));
  } catch (error) {
    yield put(actionTypes.updateStudentFailure(error.message));
  }
}

// Delete student
function* deleteStudentSaga(action) {
  try {
    const studentId = action.payload;
    yield axios.delete(`${API_BASE_URL}/students/${studentId}`);
    yield put(actionTypes.deleteStudentSuccess(studentId));
  } catch (error) {
    yield put(actionTypes.deleteStudentFailure(error.message));
  }
}

// Watcher Saga
function* studentSaga() {
  yield all([
    takeLatest(actionTypes.FETCH_STUDENTS_REQUEST, fetchStudentsSaga),
    takeLatest(actionTypes.UPDATE_STUDENT_REQUEST, updateStudentSaga),
    takeLatest(actionTypes.DELETE_STUDENT_REQUEST, deleteStudentSaga),
    yield takeLatest(actionTypes.ADD_STUDENT_REQUEST, addStudentSaga),

  ]);
}

export default studentSaga;