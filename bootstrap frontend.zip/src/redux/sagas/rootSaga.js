import { all } from 'redux-saga/effects';
import studentSaga from './studentSaga';
import departmentSaga from './departmentSaga';
import examSaga from './examSaga';
import userSaga from './userSaga';
import roleSaga from './roleSaga'

function* rootSaga() {
  // Use the all effect to run multiple sagas concurrently
  yield all([
    studentSaga(),
    departmentSaga(),
    examSaga(),
    roleSaga(),
    userSaga(),
    // Add more sagas here if needed
  ]);
}

export default rootSaga;