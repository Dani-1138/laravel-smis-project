/* import logo from './logo.svg'; */
import './App.css';
import { Routes,Route } from 'react-router-dom';
import Dashboard from './components/Dashboard';

function App() {
  return (
    <>
      <Dashboard />
    </>
  );
}

export default App;

// import React from 'react';
// import { Switch, Router, Route } from 'react-router-dom';
// import { Routes, BrowserRouter } from 'react-router-dom';
// import { useSelector } from 'react-redux';
// import Login from './components/Login';
// import AdminComponent from './pages/AdminComponent';
// import CoordinatorComponent from './pages/CoordinatorComponent';
// import RegistralComponent from './pages/RegistralComponent';
// import StudentComponent from './pages/StudentComponent';
// import ProtectedRoute from './pages/ProtectedRoute';
// import LoginForm from './components/Login';

// import { routes } from './routes';

// const App = () => {
//   // const userRole = useSelector(state => state.user.role);
//   const userRole = "student";

//   return (
// <BrowserRouter>
//     <Routes>
//     <Route path="/login" element={<LoginForm />} />
//     {routes.map((route,i) => (
//             <React.Fragment key={i}>
//               {route.isProtected ? (
//                 <Route
//                   element={
//                     <ProtectedRoute allowedRoles={route.allowedRole} userRole={userRole}>
//                       {route.element}
//                     </ProtectedRoute>
//                   }
//                   path={route.path}
//                 />
//               ) : (
//                 <Route element={route.element} path={route.path} />
//               )}
//             </React.Fragment>
//           ))}
//         {/* <Route element={<PageNotFound />} path="*" /> */}
//         {/* Add a catch-all route to handle unknown routes */}
//         {/* <Route path="*" element={<div>Page Not Found</div>} /> */}
//     </Routes>
//     </BrowserRouter>
//   )
  
// };

// export default App;
