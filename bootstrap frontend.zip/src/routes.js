// import { DiasporaPage } from 'app/pages/DiasporaPage/Loadable';
// import { IRoute } from './types';
// import { AdminBanksPage } from 'app/pages/Bankspage/Loadable';
// import { AdminPhoneOperatorPage } from 'app/pages/AdminPhoneOperator/Loadable';

import Dashboard from "./components/Dashboard";
import ViewStudentTable from "./components/ViewStudentTable";

// import { DiasporaDetailPage } from 'app/pages/DiasporaDetailPage/Loadable';
// import { AdminPhoneOperatorDetailPage } from 'app/pages/AdminPhoneOperatorDetailPage/Loadable';
// import { AdminLoanOfferPage } from 'app/pages/AdminLoanOfferPage/Loadable';
// import { PageNotFound } from 'app/components/PageNotFound';
// import { AdminBanksDetailPage } from 'app/pages/BankDetailsPage/Loadable';
// import { AdminLoanOfferDetailPage } from 'app/pages/AdminLoanOfferDetailPage/Loadable';
// import { AdminScheduledPage } from 'app/pages/AdminScheduledPage/Loadable';
// import { BanksLoanRequestPage } from 'app/pages/BanksLoanRequestPage/Loadable';
// import { BanksLoanOfferPage } from 'app/pages/BanksLoanOfferPage/Loadable';
// import { BanksLoanRequestDetailPage } from 'app/pages/BanksLoanRequestDetailPage/Loadable';
// import { BankLoanOfferDetailPage } from 'app/pages/BankLoanOfferDetailPage/Loadable';
// import { PhoneOperatorLoanRequestPage } from 'app/pages/PhoneOperatorLoanRequestPage/Loadable';
// import { PhoneOperatorLoanRequestDetailPage } from 'app/pages/PhoneOperatorLoanRequestDetailPage/Loadable';
// import { PhoneOperatorScheduledPage } from 'app/pages/PhoneOperatorScheduledPage/Loadable';
// import { AdminCreateRolesPage } from 'app/pages/AdminCreateRolesPage/Loadable';
// import { AdminDiasporaOfferPage } from 'app/pages/AdminDiasporaOfferPage/Loadable';
// import ActivationPage from 'app/pages/ActivationPage';
// import { DesignSystemPage } from 'app/pages/DesignSystemPage/Loadable';
// import ResetPasswordPage from 'app/pages/ResetPasswordPage';
// import { ForgotPasswordPage } from 'app/pages/ForgotPasswordPage';
// import { AdminDashboardPage } from 'app/pages/AdminDashboardPage';

export const routes = [
  {
    element: <Dashboard/>,
    exact: true,
    path: '/admin/dashboard',
    isProtected: true,
    allowedRole: 'admin',
  },
  {
    element: <Dashboard />,
    exact: true,
    path: '/admin/student',
    isProtected: true,
    allowedRole: 'admin',
  },
  {
    element: <Dashboard />,
    exact: true,
    path: '/student/dashboard',
    isProtected: true,
    allowedRole: 'admin',
  },
//   {
//     element: <DiasporaDetailPage />,
//     exact: true,
//     path: '/admin/diaspora/:clientId',
//     isProtected: true,
//     allowedRole: 'admin',
//   },
//   {
//     element: <AdminDiasporaOfferPage />,
//     exact: true,
//     path: '/admin/diaspora/givenOffer/:clientId',
//     isProtected: true,
//     allowedRole: 'admin',
//   },
//   {
//     element: <AdminScheduledPage />,
//     exact: true,
//     path: '/admin/scheduled',
//     isProtected: true,
//     allowedRole: 'admin',
//   },
//   {
//     element: <AdminScheduledPage />,
//     exact: true,
//     path: '/admin/scheduled/:pageNo',
//     isProtected: true,
//     allowedRole: 'admin',
//   },
//   {
//     element: <AdminPhoneOperatorDetailPage />,
//     exact: true,
//     path: '/admin/operator/:userId',
//     isProtected: true,
//     allowedRole: 'admin',
//   },
//   {
//     element: <AdminBanksPage />,
//     exact: true,
//     path: '/admin/banks',
//     isProtected: true,
//     allowedRole: 'admin',
//   },
//   {
//     element: <AdminBanksPage />,
//     exact: true,
//     path: '/admin/banks/:pageNo',
//     isProtected: true,
//     allowedRole: 'admin',
//   },
//   {
//     element: <AdminBanksDetailPage />,
//     exact: true,
//     path: 'admin/bank/:userId',
//     isProtected: true,
//     allowedRole: 'admin',
//   },
//   {
//     element: <AdminCreateRolesPage />,
//     exact: true,
//     path: '/admin/user',
//     isProtected: true,
//     allowedRole: 'admin',
//   },
//   {
//     element: <AdminCreateRolesPage />,
//     exact: true,
//     path: '/admin/user/:Id',
//     isProtected: true,
//     allowedRole: 'admin',
//   },
//   {
//     element: <AdminPhoneOperatorPage />,
//     exact: true,
//     path: '/admin/operators',
//     isProtected: true,
//     allowedRole: 'admin',
//   },
//   {
//     element: <AdminPhoneOperatorPage />,
//     exact: true,
//     path: '/admin/operators/:pageNo',
//     isProtected: true,
//     allowedRole: 'admin',
//   },
//   {
//     element: <AdminLoanOfferPage />,
//     exact: true,
//     path: '/admin/offers',
//     isProtected: true,
//     allowedRole: 'admin',
//   },
//   {
//     element: <AdminLoanOfferPage />,
//     exact: true,
//     path: '/admin/offers/:pageNo',
//     isProtected: true,
//     allowedRole: 'admin',
//   },
//   {
//     element: <AdminLoanOfferDetailPage />,
//     exact: true,
//     path: '/admin/offer/:id',
//     isProtected: true,
//     allowedRole: 'admin',
//   },
//   {
//     element: <></>,
//     exact: true,
//     path: '/bank/dashboard',
//     isProtected: true,
//     allowedRole: 'bank',
//   },
//   {
//     element: <BanksLoanRequestPage />,
//     exact: true,
//     path: '/bank/requests',
//     isProtected: true,
//     allowedRole: 'bank',
//   },
//   {
//     element: <BanksLoanRequestPage />,
//     exact: true,
//     path: '/bank/requests/:pageNo',
//     isProtected: true,
//     allowedRole: 'bank',
//   },
//   {
//     element: <BanksLoanRequestDetailPage />,
//     exact: true,
//     path: '/bank/request/:requestId',
//     isProtected: true,
//     allowedRole: 'bank',
//   },
//   {
//     element: <BanksLoanOfferPage />,
//     exact: true,
//     path: '/bank/offers',
//     isProtected: true,
//     allowedRole: 'bank',
//   },
//   {
//     element: <BanksLoanOfferPage />,
//     exact: true,
//     path: '/bank/offers/:pageNo',
//     isProtected: true,
//     allowedRole: 'bank',
//   },
//   {
//     element: <BankLoanOfferDetailPage />,
//     exact: true,
//     path: '/bank/offer/:offerId',
//     isProtected: true,
//     allowedRole: 'bank',
//   },

//   {
//     element: <></>,
//     exact: true,
//     path: '/telephonist/dashboard',
//     isProtected: true,
//     allowedRole: 'telephonist',
//   },
//   {
//     element: <PhoneOperatorLoanRequestPage />,
//     exact: true,
//     path: '/telephonist/requests',
//     isProtected: true,
//     allowedRole: 'telephonist',
//   },
//   {
//     element: <PhoneOperatorLoanRequestPage />,
//     exact: true,
//     path: '/telephonist/requests/:pageNo',
//     isProtected: true,
//     allowedRole: 'telephonist',
//   },
//   {
//     element: <PhoneOperatorLoanRequestDetailPage />,
//     exact: true,
//     path: '/telephonist/request/:id',
//     isProtected: true,
//     allowedRole: 'telephonist',
//   },
//   {
//     element: <PhoneOperatorScheduledPage />,
//     exact: true,
//     path: '/telephonist/scheduled',
//     isProtected: true,
//     allowedRole: 'telephonist',
//   },

//   {
//     element: <PhoneOperatorScheduledPage />,
//     exact: true,
//     path: '/telephonist/scheduled/:pageNo',
//     isProtected: true,
//     allowedRole: 'telephonist',
//   },
//   {
//     element: <PageNotFound />,
//     exact: true,
//     path: '/notfound',
//     isProtected: false,
//     allowedRole: '*',
//   },
//   {
//     element: <ActivationPage />,
//     exact: true,
//     path: '/activate',
//     isProtected: false,
//     allowedRole: '*',
//   },
//   {
//     element: <DesignSystemPage />,
//     exact: true,
//     path: '/design',
//     isProtected: false,
//     allowedRole: '*',
//   },
//   {
//     element: <ResetPasswordPage />,
//     exact: true,
//     path: '/reset-password',
//     isProtected: false,
//     allowedRole: '*',
//   },
//   {
//     element: <ForgotPasswordPage />,
//     exact: true,
//     path: '/forgot-password',
//     isProtected: false,
//     allowedRole: '*',
//   },
//   {
//     element: <DesignSystemPage />,
//     exact: true,
//     path: '/design',
//     isProtected: false,
//     allowedRole: '*',
//   },
//   {
//     element: <ResetPasswordPage />,
//     exact: true,
//     path: '/reset-password',
//     isProtected: false,
//     allowedRole: '*',
//   },
//   {
//     element: <ForgotPasswordPage />,
//     exact: true,
//     path: '/forgot-password',
//     isProtected: false,
//     allowedRole: '*',
//   },
  
];
